using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class EnemyManager : MonoBehaviour
{
    public static EnemyManager Instance;
    private List<Enemy> enemies = new List<Enemy>();

    private void Awake()
    {
        Instance = this;
    }

    public void RegisterEnemy(Enemy enemy)
    {
        enemies.Add(enemy);
    }

    public void RemoveEnemy(Enemy enemy)
    {
        if (enemies.Contains(enemy))
        {
            enemies.Remove(enemy);
            Debug.Log($"Enemy {enemy.gameObject.name} 被移除！");
        }
    }

    public void ProcessEnemyTurn()
    {
        enemies.RemoveAll(enemy => enemy == null); // 移除已经被销毁的敌人
        StartCoroutine(EnemyTurnRoutine());
    }

    private IEnumerator EnemyTurnRoutine()
    {
        foreach (Enemy enemy in enemies)
        {
            yield return new WaitForSeconds(0.5f);
            enemy.TakeAction();
        }

        GameManager.Instance.OnEnemyTurnEnd();
        GameManager.Instance.EndTurn();
    }
}
