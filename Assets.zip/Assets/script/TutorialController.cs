using UnityEngine;

public class MenuController : MonoBehaviour
{
    public GameObject tutorialPanel; // 拖入 TutorialPanel

    public void ShowTutorial()
    {
        tutorialPanel.SetActive(true); // 显示教程
    }

    public void HideTutorial()
    {
        tutorialPanel.SetActive(false); // 隐藏教程
    }
}
