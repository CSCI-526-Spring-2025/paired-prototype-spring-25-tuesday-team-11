using UnityEngine;
using UnityEngine.Tilemaps;
public class Obstacle : MonoBehaviour
{
    private int health = 20;
    public GameObject dropItemPrefab; // ����ĵ���
    public ObstacleHealth oHealth;
    public Vector3Int currentCell;
    public Tilemap tilemap;

    private void Start()
    {
        currentCell = tilemap.WorldToCell(transform.position);
        transform.position = tilemap.GetCellCenterWorld(currentCell);
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        Debug.Log($"障碍物受到了 {damage} 点伤害，剩余血量{health}");
        oHealth.TakeDamage(damage);
        if (health <= 0)
        {
            Destroy(gameObject);
            DropItem();
        }
    }

    void DropItem()
    {
        if (dropItemPrefab != null)
        {
            Instantiate(dropItemPrefab, transform.position, Quaternion.identity);
        }
    }
}