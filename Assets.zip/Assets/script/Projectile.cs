using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections;

public class Projectile : MonoBehaviour
{
    public int damage = 10;
    public float moveSpeed = 0.2f;
    private int maxTilesToTravel;
    private Vector3Int direction;
    private Vector3Int currentCell;
    private Tilemap tilemap;

    public void Initialize(Vector3Int dir, Tilemap tilemap, int maxDistance)
    {
        this.direction = dir;
        this.tilemap = tilemap;
        this.maxTilesToTravel = maxDistance;
        currentCell = tilemap.WorldToCell(transform.position);
        StartCoroutine(MoveProjectile());
    }

    private IEnumerator MoveProjectile()
    {
        for (int i = 0; i < maxTilesToTravel; i++)
        {
            yield return new WaitForSeconds(moveSpeed);

            Vector3Int nextCell = currentCell + direction;
            Vector3 nextPosition = tilemap.GetCellCenterWorld(nextCell);

            Collider2D hit = Physics2D.OverlapCircle(nextPosition, 0.6f, LayerMask.GetMask("Enemy", "Obstacle"));
            
            if (hit)
            {
                Debug.Log($"检测碰撞位置: {nextPosition}, 碰撞对象: {hit?.gameObject.name}");
                if (hit.CompareTag("Enemy"))
                {
                    hit.GetComponent<Enemy>().TakeDamage(damage);
                }
                else if (hit.CompareTag("Obstacle"))
                {
                    hit.GetComponent<Obstacle>().TakeDamage(damage);
                }

                Destroy(gameObject);
                yield break;
            }

            currentCell = nextCell;
            transform.position = nextPosition;
        }

        Destroy(gameObject);
    }
}